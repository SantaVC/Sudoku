﻿namespace SudokuTest
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveGameBtn = new System.Windows.Forms.Button();
            this.loadGameBtn = new System.Windows.Forms.Button();
            this.solveBtn = new System.Windows.Forms.Button();
            this.generageBtn = new System.Windows.Forms.Button();
            this.checkResult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // saveGameBtn
            // 
            this.saveGameBtn.Location = new System.Drawing.Point(657, 51);
            this.saveGameBtn.Name = "saveGameBtn";
            this.saveGameBtn.Size = new System.Drawing.Size(112, 23);
            this.saveGameBtn.TabIndex = 1;
            this.saveGameBtn.Text = "Save Game";
            this.saveGameBtn.UseVisualStyleBackColor = true;
            this.saveGameBtn.Click += new System.EventHandler(this.saveGameBtn_Click);
            // 
            // loadGameBtn
            // 
            this.loadGameBtn.Location = new System.Drawing.Point(657, 80);
            this.loadGameBtn.Name = "loadGameBtn";
            this.loadGameBtn.Size = new System.Drawing.Size(112, 23);
            this.loadGameBtn.TabIndex = 2;
            this.loadGameBtn.Text = "Load Last Game";
            this.loadGameBtn.UseVisualStyleBackColor = true;
            this.loadGameBtn.Click += new System.EventHandler(this.loadGameBtn_Click);
            // 
            // solveBtn
            // 
            this.solveBtn.Location = new System.Drawing.Point(657, 109);
            this.solveBtn.Name = "solveBtn";
            this.solveBtn.Size = new System.Drawing.Size(112, 23);
            this.solveBtn.TabIndex = 3;
            this.solveBtn.Text = "Solve";
            this.solveBtn.UseVisualStyleBackColor = true;
            this.solveBtn.Click += new System.EventHandler(this.solveBtn_Click);
            // 
            // generageBtn
            // 
            this.generageBtn.Location = new System.Drawing.Point(657, 22);
            this.generageBtn.Name = "generageBtn";
            this.generageBtn.Size = new System.Drawing.Size(112, 23);
            this.generageBtn.TabIndex = 4;
            this.generageBtn.Text = "Generate";
            this.generageBtn.UseVisualStyleBackColor = true;
            this.generageBtn.Click += new System.EventHandler(this.generageBtn_Click);
            // 
            // checkResult
            // 
            this.checkResult.Location = new System.Drawing.Point(657, 506);
            this.checkResult.Name = "checkResult";
            this.checkResult.Size = new System.Drawing.Size(112, 23);
            this.checkResult.TabIndex = 5;
            this.checkResult.Text = "Check Result";
            this.checkResult.UseVisualStyleBackColor = true;
            this.checkResult.Click += new System.EventHandler(this.checkResult_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 563);
            this.Controls.Add(this.checkResult);
            this.Controls.Add(this.generageBtn);
            this.Controls.Add(this.solveBtn);
            this.Controls.Add(this.loadGameBtn);
            this.Controls.Add(this.saveGameBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button saveGameBtn;
        private System.Windows.Forms.Button loadGameBtn;
        private System.Windows.Forms.Button solveBtn;
        private System.Windows.Forms.Button generageBtn;
        private System.Windows.Forms.Button checkResult;
    }
}

