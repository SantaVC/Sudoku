﻿using System;
using System.IO;
using System.Windows.Forms;

namespace SudokuTest
{
    public partial class Form1 : Form
    {
        private MapGenerator MapGenerator;
        private GameEvents gameEvents;
        string filePath = Path.Combine(Application.StartupPath, "savedGame.txt");

        public Form1()
        {
            InitializeComponent();
            MapGenerator = new MapGenerator(this);
            gameEvents = new GameEvents(MapGenerator);
            MapGenerator.GenerateMap();            
            this.FormClosing += Form1_FormClosing;
            if (File.Exists(filePath))
                gameEvents.LoadGame(filePath);
            gameEvents.CheckMapNumbers();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void saveGameBtn_Click(object sender, EventArgs e)
        {
            
            gameEvents.SaveGame(filePath);
        }

        private void loadGameBtn_Click(object sender, EventArgs e)
        {
            gameEvents.LoadGame(filePath);
        }

        private void solveBtn_Click(object sender, EventArgs e)
        {
            gameEvents.ResetMapValues();
            gameEvents.CheckSolve();
            gameEvents.CheckMapNumbers();

        }

        private void generageBtn_Click(object sender, EventArgs e)
        {
            gameEvents.ResetMapValues();
            MapGenerator.GenerateMap();
            gameEvents.CheckMapNumbers();

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            gameEvents.SaveGame(filePath);
        }

        private void checkResult_Click(object sender, EventArgs e)
        {
            gameEvents.checkWin();
        }
    }
}