﻿using System;
using System.IO;
using System.Windows.Forms;

namespace SudokuTest
{
    public partial class Form1 : Form
    {
        private MapGenerator MapGenerator;
        private GameEvents gameEvents;

        public Form1()
        {
            InitializeComponent();
            MapGenerator = new MapGenerator(this);
            gameEvents = new GameEvents(MapGenerator);
            MapGenerator.GenerateMap();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void saveGameBtn_Click(object sender, EventArgs e)
        {
            string filePath = Path.Combine(Application.StartupPath, "savedGame.txt");
            gameEvents.SaveGame(filePath);
        }

        private void loadGameBtn_Click(object sender, EventArgs e)
        {
            string filePath = Path.Combine(Application.StartupPath, "savedGame.txt");
            gameEvents.LoadGame(filePath);
        }

        private void solveBtn_Click(object sender, EventArgs e)
        {
            gameEvents.CheckSolve();

        }

        private void generageBtn_Click(object sender, EventArgs e)
        {
            MapGenerator.GenerateMap();
        }
    }
}