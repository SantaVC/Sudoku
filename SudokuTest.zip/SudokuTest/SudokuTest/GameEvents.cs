﻿using System;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SudokuTest
{
    [Serializable]
    public class GameSaveData
    {
        public int[,] map;
        public bool[,] buttonVisibility;
        public string[,] buttonText;
    }
    public class GameEvents
    {
        private MapGenerator generator;
        private SolveSudoku solveSudoku;

        private int blockSize = MapGenerator.blockSize;


        // Constructor for the GameEvents class.
        // Initializes the SudokuGenerator and SolveSudoku instances.
        public GameEvents(MapGenerator generator)
        {
            this.generator = generator;
            solveSudoku = new SolveSudoku(generator);
        }



        public void SaveGame(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                for (int row = 0; row < blockSize * blockSize; row++)
                {
                    for (int col = 0; col < blockSize * blockSize; col++)
                    {
                        int value;
                        if (!string.IsNullOrEmpty(generator.buttons[row, col].Text) && int.TryParse(generator.buttons[row, col].Text, out int parsedValue))
                        {
                            value = parsedValue;
                        }
                        else
                        {
                            value = 0;
                        }
                        writer.Write($"{value} ");
                    }
                    writer.WriteLine();
                }

                writer.WriteLine("-----------------");

                for (int row = 0; row < blockSize * blockSize; row++)
                {
                    int bitValue = 0;
                    for (int col = 0; col < blockSize * blockSize; col++)
                    {
                        if (generator.buttons[row, col].Enabled)
                        {
                            bitValue |= (1 << col);
                        }
                    }
                    writer.Write($"{bitValue} ");
                    writer.WriteLine();
                }
            }
        }

        public void LoadGame(string filePath)
        {
            if (File.Exists(filePath))
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    for (int row = 0; row < blockSize * blockSize; row++)
                    {
                        string line = reader.ReadLine();
                        string[] entries = line.Split(' ');

                        for (int col = 0; col < blockSize * blockSize; col++)
                        {
                            int value;
                            if (int.TryParse(entries[col], out value) && value >= 0 && value <= 9)
                            {
                                generator.map[row, col] = value;
                                generator.buttons[row, col].Text = value == 0 ? "" : value.ToString();
                                generator.buttons[row, col].Enabled = true;
                                generator.buttons[row, col].BackColor = Color.White;
                            }
                            else
                            {
                                generator.map[row, col] = 0;
                                generator.buttons[row, col].Text = "";
                                generator.buttons[row, col].Enabled = true;
                                generator.buttons[row, col].BackColor = Color.White;
                            }
                        }
                    }

                    reader.ReadLine();

                    for (int row = 0; row < blockSize * blockSize; row++)
                    {
                        string line = reader.ReadLine();
                        string[] entries = line.Split(' ');

                        int bitValue = int.Parse(entries[0]);
                        for (int col = 0; col < blockSize * blockSize; col++)
                        {
                            bool isEnabled = ((bitValue >> col) & 1) == 1;
                            generator.buttons[row, col].Enabled = isEnabled;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Can't find Save File");
            }
        }



        // This method is executed when a cell is clicked.
        // It increments the cell's number or clears it if the number is 9.
        public void OnCellPressed(object sender, EventArgs e)
        {
            Button pressedBtn = sender as Button;
            string buttonText = pressedBtn.Text;
            if (string.IsNullOrEmpty(buttonText))
            {
                pressedBtn.Text = "1";
            }
            else
            {
                int num = int.Parse(buttonText);
                num++;
                if (num >= 10)
                {
                    pressedBtn.Text = string.Empty;
                }
                else
                {
                    pressedBtn.Text = num.ToString();
                }
            }
            CheckMapNumbers();
        }



        // Checks if the current state of the game is solvable.
        // If it is, it fills all cells with their correct numbers.
        public void CheckSolve()
        {
            if (solveSudoku.SudokuSolver())
            {
                for (int i = 0; i < blockSize * blockSize; i++)
                {
                    for (int j = 0; j < blockSize * blockSize; j++)
                    {
                        generator.UpdateUI(i, j, generator.map[i, j]);
                    }
                }
            }
            else
            {
                MessageBox.Show("Unsolvable");
            }
        }


        // Resets the values of the map to 0 for all enabled buttons.
        public void ResetMapValues()
        {
            for (int row = 0; row < blockSize * blockSize; row++)
            {
                for (int col = 0; col < blockSize * blockSize; col++)
                {
                    if (generator.buttons[row, col].Enabled)
                    {
                        generator.map[row, col] = 0;
                    }
                }
            }
        }


        // Checks if the player has won the game by comparing the button text with the corresponding map values.
        // Displays a message box indicating the result and generates a new map if the player wins.
        public void checkWin()
        {
            for (int i = 0; i < blockSize * blockSize; i++)
            {
                for (int j = 0; j < blockSize * blockSize; j++)
                {
                    var btnText = generator.buttons[i, j].Text;
                    if (btnText != generator.map[i, j].ToString())
                    {
                        MessageBox.Show("You are lose!");
                        return;
                    }
                }
            }
            MessageBox.Show("You are win");
            generator.GenerateMap();
        }


        // Checks the counts of each digit on the map and hides or shows the corresponding number labels accordingly.
        public void CheckMapNumbers()
        {
            int[] counts = CountDigits();

            for (int i = 0; i < counts.Length; i++)
            {
                if (counts[i] >= 9)
                {
                    generator.numberLabels[i].Visible = false;
                }
                else
                {
                    generator.numberLabels[i].Visible = true;
                }
            }

        }


        /// <summary>
        /// Counts the occurrences of each digit (1-9) on the map and returns an array with the counts.
        /// </summary>
        /// <returns>An array containing the counts of each digit on the map.</returns>
        public int[] CountDigits()
        {
            int[] counts = new int[9];

            for (int i = 0; i < blockSize * blockSize; i++)
            {
                for (int j = 0; j < blockSize * blockSize; j++)
                {
                    string buttonText = generator.buttons[i, j].Text;
                    if (!string.IsNullOrEmpty(buttonText))
                    {
                        int number = int.Parse(buttonText);
                        if (number >= 1 && number <= 9)
                        {
                            counts[number - 1]++;
                        }
                    }
                }
            }

            return counts;
        }

    }
}
