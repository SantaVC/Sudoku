﻿using System;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace SudokuTest
{
    [Serializable]
    public class GameSaveData
    {
        public int[,] map;
        public bool[,] buttonVisibility;
        public string[,] buttonText;
    }
    public class GameEvents
    {
        private MapGenerator generator;
        private SolveSudoku solveSudoku;

        private int blockSize = MapGenerator.blockSize;


        // Constructor for the GameEvents class.
        // Initializes the SudokuGenerator and SolveSudoku instances.
        public GameEvents(MapGenerator generator)
        {
            this.generator = generator;
            solveSudoku = new SolveSudoku(generator);
        }



        // Saves the current state of the game to a file.
        // The file contains the map entries, button texts and enabled states for all cells.
        public void SaveGame(string filePath)
        {
            GameSaveData saveData = new GameSaveData();
            saveData.map = generator.map;
            saveData.buttonVisibility = new bool[blockSize * blockSize, blockSize * blockSize];
            saveData.buttonText = new string[blockSize * blockSize, blockSize * blockSize];

            for (int i = 0; i < blockSize * blockSize; i++)
            {
                for (int j = 0; j < blockSize * blockSize; j++)
                {
                    saveData.buttonVisibility[i, j] = generator.buttons[i, j].Enabled;
                    saveData.buttonText[i, j] = generator.buttons[i, j].Text;
                }
            }

            try
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fileStream, saveData);
                }
                Console.WriteLine("Game has been saved");
            }
            catch (IOException e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }


        // Loads a game state from a file.
        // The file should contain the map entries, button texts and enabled states for all cells.
        public void LoadGame(string filePath)
        {
            try
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    GameSaveData saveData = (GameSaveData)formatter.Deserialize(fileStream);

                    generator.map = saveData.map;

                    for (int i = 0; i < blockSize * blockSize; i++)
                    {
                        for (int j = 0; j < blockSize * blockSize; j++)
                        {
                            generator.buttons[i, j].Enabled = saveData.buttonVisibility[i, j];
                            generator.buttons[i, j].Text = saveData.buttonText[i, j];
                            generator.buttons[i, j].BackColor = Color.White;
                        }
                    }
                }
                Console.WriteLine("Game has been loaded");
            }
            catch (IOException e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }


        // Checks if the current state of the game is solvable.
        // If it is, it fills all cells with their correct numbers.
        public void CheckSolve()
        {
            if (solveSudoku.SudokuSolver())
            {
                for (int i = 0; i < blockSize * blockSize; i++)
                {
                    for (int j = 0; j < blockSize * blockSize; j++)
                    {
                        generator.UpdateUI(i, j, generator.map[i, j]);
                    }
                }
            }
        }

    }
}
